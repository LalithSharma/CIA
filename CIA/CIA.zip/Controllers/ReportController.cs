﻿using CIA_BLL.ErrorHandling;
using CIA_MAL.Model;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace CIA.Controllers
{
    public class ReportController : Controller
    {
        // GET: Report
        public ActionResult Report()
        {
            return View();
        }

        public JsonResult SaveToExcel(string excel_name, string sheet_name, string table_id, string fyear, string quart, int reports, string typ_report)
        {
            ResultStatus rs = new ResultStatus();
            try
            {
                //string excel_filename = "";
                //if (reports == 2)
                //{
                //    excel_filename = "CPF_Detailed_Report_" + typ_report + "_" + DateTime.Now.ToString("yyyymmddHHmmss") + ".xlsx";
                //    rs = sobj.DetailedRpt_ExcelDwn(excel_filename, sheet_name, table_id, fyear, quart, typ_report);
                //}
                //else if (reports == 1)
                //{
                //    excel_filename = "CPF_Completion_Report_" + DateTime.Now.ToString("yyyymmddHHmmss") + ".xlsx";
                //    rs = sobj.CmpltedRpt_ExcelDwn(excel_filename, sheet_name, table_id, fyear, quart, typ_report);
                //}
                //else
                //{
                //    rs.Status = "Failure";
                //}
            }
            catch (Exception ex)
            {
                rs.Status = "Failure";
                if (ex.Message != null || ex.Message != "")
                {
                    rs.MSG = ex.Message;
                }
                else
                {
                    rs.MSG = ex.StackTrace;
                }
                ExceptionLogging.LogException(ex);
            }
            return Json(rs, JsonRequestBehavior.AllowGet);
        }

        public ActionResult Download_Excel()
        {
            ExceptionLogging obj = new ExceptionLogging();
            if (Session["fPath"] == null)
            {
                obj.Logcreation("DownloadExcel Report Error - File path is null.");
                return RedirectToAction("Dashboard");
            }
            else
            {
                string fpath = Session["fPath"].ToString();
                obj.Logcreation("DownloadExcel Report Success in path : " + fpath);
                Session["fPath"] = null;
                FileInfo file = new FileInfo(fpath);
                byte[] fileBytes = System.IO.File.ReadAllBytes(fpath);
                return File(fileBytes, System.Net.Mime.MediaTypeNames.Application.Octet, file.Name);
            }
        }
    }
}