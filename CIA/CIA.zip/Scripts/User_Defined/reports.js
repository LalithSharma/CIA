﻿var app = angular.module('Myreport', [])
app.controller('report_Controller', function ($scope, $http, $window) {

    $scope.finyr = "";
    $scope.qua = "";
    $scope.dwn_report = "";
    $scope.report_typ = "";
    //------------------------get list of all employee under manager_id------------------
    $scope.getallemployee = function () {
        ShowProgress();

        var durl = angular.element(document.getElementById("GetDetails")).val();

        $http({
            method: "POST",
            url: durl,
            data: {}

        }).then(function onSuccess(resp) {
            if (resp.data.Status == 'Success') {
                $scope.reportings = resp.data.obj;
                $scope.fyear = resp.data.obj;
                $scope.quarterly = resp.data.obj;
            }
            else {
                MsgBox('E', 'Error', 'An error occurred while processing your request.Please contact admin');
            }
            HideProgress();
        },
   function onFailure(err) {
       HideProgress();
       alert(err.data.statusText);
   });
        HideProgress();
    }

    $scope.getallemployee();


    $scope.exportToExcel = function (tableId) {
        ResetClientSideSessionTimers();
        ShowProgress();

        if ($scope.dwn_report == undefined || $scope.dwn_report == "-Select-") {
            MsgBox('E', 'Error', 'Please select Report.');
        }
        else if ($scope.frmdate == undefined || $scope.frmdate == "") {
            MsgBox('E', 'Error', 'Please select Start Date.');
        }
        else if ($scope.enddate == undefined || $scope.enddate == "") {
            MsgBox('E', 'Error', 'Please select End date.');
        }
        else if ($scope.status == undefined || $scope.status == "") {
            MsgBox('E', 'Error', 'Please select status.');
        }

        //else if ($scope.dwn_report == 2 && ($scope.report_typ == undefined || $scope.report_typ == "-Select-" || $scope.report_typ == "")) {
        //    //alert($scope.dwn_report);
        //    MsgBox('E', 'Error', 'Please select the Assessment Type.');
        //}
        else {
            var today = new Date();
            var curr_month = ("0" + (today.getMonth() + 1)).slice(-2);
            var curr_date = ("0" + today.getDate()).slice(-2);
            var curr_year = today.getFullYear();
            var curr_hours = ("0" + today.getHours()).slice(-2);
            var curr_minutes = ("0" + today.getMinutes()).slice(-2);
            var curr_seconds = ("0" + today.getSeconds()).slice(-2);

            var date = curr_year + '' + curr_month + '' + curr_date;
            var time = curr_hours + '' + curr_minutes + '' + curr_seconds;
            var dateTime = date + '' + time;
            var excelname = "CI_Report_" + dateTime + ".xlsx";
            var sheetname = curr_year + '-' + curr_month + '-' + curr_date;
            var SaveToExcel_V = angular.element(document.getElementById("SaveToExcel"));
            $scope.new = {
                excel_name: excelname,
                sheet_name: sheetname,
                table_id: tableId,
                fyear: $scope.finyr,
                quart: $scope.qua,
                reports: $scope.dwn_report,
                typ_report: $scope.report_typ
            }
            //alert(SaveToExcel_V.val());
            $http({
                method: 'POST',
                url: SaveToExcel_V.val(),
                data: $scope.new
            }).then(function (response) {
                //alert("xx");
                if (response.data.Status == 'Success') {
                    // alert("xxx");
                    HideProgress();
                    ResetClientSideSessionTimers();
                    var Download_Excel_V = angular.element(document.getElementById("Download_Excel"));
                    window.location.href = Download_Excel_V.val();
                }
                else {
                    HideProgress();
                    ResetClientSideSessionTimers();
                    MsgBox('E', 'Error', response.data.MSG);
                    return;
                }
            }, function (error) {
                HideProgress();
                ResetClientSideSessionTimers();
                MsgBox('E', 'Error', error.data);
                return;
            });
        }
    };

});